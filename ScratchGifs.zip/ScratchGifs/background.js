// =========================================================
// SCRATCH GIFS - BACKGROUND.JS
// Catbox.moe upload proxy
// =========================================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    if (message.action === "uploadToCatbox") {

        uploadToCatbox(
            message.fileData,
            message.fileName,
            message.fileType
        )
            .then(url => sendResponse({ success: true, url }))
            .catch(err => sendResponse({
                success: false,
                error: err.message || String(err)
            }));

        // async response için true döndür
        return true;
    }

    return false;
});


async function uploadToCatbox(base64Data, fileName, fileType) {

    if (!base64Data) {
        throw new Error("No file data");
    }

    // base64 -> Blob
    const binary = atob(base64Data);

    const bytes = new Uint8Array(binary.length);

    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }

    const blob = new Blob(
        [bytes],
        { type: fileType || "image/gif" }
    );

    const file = new File(
        [blob],
        fileName || "custom.gif",
        { type: fileType || "image/gif" }
    );


    const formData = new FormData();

    formData.append("reqtype", "fileupload");
    formData.append("fileToUpload", file);


    const response = await fetch(
        "https://catbox.moe/user/api.php",
        {
            method: "POST",
            body: formData
        }
    );


    if (!response.ok) {
        throw new Error(
            "Upload failed: HTTP " + response.status
        );
    }


    const url = (await response.text()).trim();


    if (!url || !/^https?:\/\//i.test(url)) {
        throw new Error(
            "Invalid response: " + url.slice(0, 100)
        );
    }


    return url;
}