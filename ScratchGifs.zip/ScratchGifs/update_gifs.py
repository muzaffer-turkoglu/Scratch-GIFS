from pathlib import Path
import json

BASE = Path(__file__).parent
GIFS_DIR = BASE / "gifs"
INDEX_FILE = GIFS_DIR / "index.json"

items = []

for folder in sorted(GIFS_DIR.iterdir()):
    if not folder.is_dir():
        continue

    info_file = folder / "info.json"

    if not info_file.exists():
        print(f"[ATLANDI] info.json yok: {folder.name}")
        continue

    try:
        with info_file.open("r", encoding="utf-8") as f:
            info = json.load(f)
    except Exception as e:
        print(f"[HATA] {folder.name}/info.json: {e}")
        continue

    file = info.get("file")
    name = info.get("name")
    tags = info.get("tags", [])

    if not file or not name:
        print(f"[ATLANDI] name/file eksik: {folder.name}")
        continue

    if not isinstance(tags, list):
        tags = []

    gif_file = folder / file

    if not gif_file.exists():
        print(f"[ATLANDI] GIF yok: {gif_file}")
        continue

    items.append({
        "folder": folder.name,
        "file": file,
        "name": name,
        "tags": tags
    })

index = {
    "version": 2,
    "gifs": items
}

with INDEX_FILE.open("w", encoding="utf-8") as f:
    json.dump(
        index,
        f,
        ensure_ascii=False,
        indent=2
    )

print()
print(f"{len(items)} GIF bulundu.")
print("index.json güncellendi.")