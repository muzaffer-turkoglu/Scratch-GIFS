Scratch GIFS 2.0
Unzip the downloaded file.
In Google Chrome, go to: `chrome://extensions`
Enable "Developer mode" in the top-right corner.
Click "Load unpacked" in the top-left corner.
Select the unzipped folder.
Active the extension
Now, you can use pre-existing GIFs or upload your own in studios, as well as in profile and project comments. You will also be able to see GIFs posted by other users who have the extension installed.
For those who do not have the extension, the following message will appear: "GIF: (Name of the posted GIF). You cannot see the GIF because you do not have the GIF extension."