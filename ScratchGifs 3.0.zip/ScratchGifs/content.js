(() => {
    "use strict";

    // =========================================================
    // SCRATCH GIFS - CONTENT.JS
    // =========================================================

    const GIF_ROOT = chrome.runtime.getURL("gifs/");
    const INDEX_URL = chrome.runtime.getURL("gifs/index.json");

    const ZW = [
        "\u200B",
        "\u200C",
        "\u200D",
        "\u2060"
    ];

    const START = "\u2061";
    const END = "\u2062";

    const MAX_CUSTOM_SIZE = 10 * 1024 * 1024;

    let catalog = [];

    let selectedGif = null;
    let selectedCustomFile = null;
    let selectedCustomUrl = null;

    let currentInput = null;
    let currentButton = null;
    let panel = null;

    let scanTimer = null;

    const downloadedCustoms = new Map();


    // =========================================================
    // FALLBACK METNİ
    // =========================================================

    function makeFallbackText(gifName) {
        const name = gifName || "GIF";
        return `GIF: ${name}. You can't see GIFs if you don't have @Kanka_1's ScratchGIFS extension.`;
    }


    // =========================================================
    // GIF INDEX
    // =========================================================

    async function loadCatalog() {
        try {
            const response = await fetch(INDEX_URL + "?v=" + Date.now());
            if (!response.ok) throw new Error("index.json yüklenemedi");
            const data = await response.json();
            catalog = Array.isArray(data.gifs) ? data.gifs : [];
            console.log("[ScratchGifs]", catalog.length, "GIF bulundu.");
        } catch (error) {
            console.error("[ScratchGifs] index.json hatası:", error);
            catalog = [];
        }
    }


    // =========================================================
    // GIF URL
    // =========================================================

    function getGifUrl(gif) {
        return GIF_ROOT + encodeURIComponent(gif.folder) + "/" + encodeURIComponent(gif.file);
    }


    // =========================================================
    // NORMAL GIF MARKER
    // =========================================================

    function encodeGif(folder) {
        let result = START;
        for (const char of folder) {
            const code = char.charCodeAt(0);
            result += ZW[(code >> 6) & 3];
            result += ZW[(code >> 4) & 3];
            result += ZW[(code >> 2) & 3];
            result += ZW[code & 3];
        }
        result += END;
        return result;
    }


    function decodeGif(text) {
        const start = text.indexOf(START);
        if (start === -1) return null;

        const end = text.indexOf(END, start + 1);
        if (end === -1) return null;

        const encoded = text.slice(start + 1, end);
        if (encoded.length % 4 !== 0) return null;

        let folder = "";
        for (let i = 0; i < encoded.length; i += 4) {
            let value = 0;
            for (let j = 0; j < 4; j++) {
                const index = ZW.indexOf(encoded[i + j]);
                if (index === -1) return null;
                value = (value << 2) | index;
            }
            folder += String.fromCharCode(value);
        }
        return folder;
    }


    function removeMarker(text) {
        const start = text.indexOf(START);
        if (start === -1) return text;
        const end = text.indexOf(END, start + 1);
        if (end === -1) return text;
        return text.slice(0, start) + text.slice(end + 1);
    }


    // =========================================================
    // CUSTOM GIF
    // =========================================================

    function createCustomId() {
        return (
            "custom_" +
            Date.now().toString(36) +
            "_" +
            Math.random().toString(36).slice(2, 10)
        );
    }


    function encodeCustom(id, url) {
        return id + "|" + url;
    }


    const CUSTOM_REGEX = /(custom_[a-z0-9_]+)\|(https?:\/\/files\.catbox\.moe\/[a-zA-Z0-9]+\.(?:gif|png|jpg|jpeg|webp))/i;


    function extractCustom(text) {
        const match = text.match(CUSTOM_REGEX);
        if (!match) return null;
        return {
            id: match[1],
            url: match[2],
            fullMatch: match[0]
        };
    }


    // =========================================================
    // BASE64
    // =========================================================

    function fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const result = reader.result;
                const comma = result.indexOf(",");
                resolve(comma === -1 ? result : result.slice(comma + 1));
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }


    function uploadViaBackground(file) {
        return new Promise(async (resolve, reject) => {
            try {
                const base64 = await fileToBase64(file);
                chrome.runtime.sendMessage(
                    {
                        action: "uploadToCatbox",
                        fileData: base64,
                        fileName: file.name || "custom.gif",
                        fileType: file.type || "image/gif"
                    },
                    (response) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                            return;
                        }
                        if (!response) {
                            reject(new Error("No response from background"));
                            return;
                        }
                        if (!response.success) {
                            reject(new Error(response.error || "Upload failed"));
                            return;
                        }
                        resolve(response.url);
                    }
                );
            } catch (e) {
                reject(e);
            }
        });
    }


    // =========================================================
    // GIF SEARCH
    // =========================================================

    function searchGifs(query) {
        query = (query || "").trim().toLowerCase();
        if (!query) return catalog.slice(0, 10);
        const words = query.split(/\s+/).filter(Boolean);
        return catalog.filter((gif) => {
            const searchable = [
                gif.name || "",
                gif.folder || "",
                ...(Array.isArray(gif.tags) ? gif.tags : [])
            ].join(" ").toLowerCase();
            return words.every(word => searchable.includes(word));
        });
    }


    // =========================================================
    // PANEL
    // =========================================================

    function closePanel() {
        if (panel) panel.remove();
        if (selectedCustomUrl) URL.revokeObjectURL(selectedCustomUrl);
        panel = null;
        selectedGif = null;
        selectedCustomFile = null;
        selectedCustomUrl = null;
        currentInput = null;
        currentButton = null;
    }


    function positionPanel() {
        if (!panel || !currentButton) return;
        const rect = currentButton.getBoundingClientRect();
        const panelWidth = 390;
        const panelHeight = 500;
        const gap = 7;
        let left = rect.left;
        let top = rect.bottom + gap;
        if (top + panelHeight > window.innerHeight - 8) top = rect.top - panelHeight - gap;
        if (left + panelWidth > window.innerWidth - 8) left = window.innerWidth - panelWidth - 8;
        if (left < 8) left = 8;
        if (top < 8) top = 8;
        panel.style.left = `${left}px`;
        panel.style.top = `${top}px`;
    }


    function createPanel(input, button) {
        closePanel();
        currentInput = input;
        currentButton = button;

        panel = document.createElement("div");
        panel.id = "scratch-gif-panel";

        panel.innerHTML = `
            <div class="sgif-panel-header">
                <div class="sgif-panel-title">GIFs</div>
                <button class="sgif-x" type="button" aria-label="Close">×</button>
            </div>
            <div class="sgif-search-row">
                <input class="sgif-search" type="text" placeholder="Search GIFs..." autocomplete="off">
                <button class="sgif-search-button" type="button">Search</button>
            </div>
            <div class="sgif-status">Popular GIFs</div>
            <div class="sgif-results"></div>
            <div class="sgif-custom">
                <label class="sgif-upload-button" for="sgif-custom-file">Upload GIF</label>
                <input id="sgif-custom-file" class="sgif-custom-file" type="file" accept="image/gif,image/png,.gif,.png">
                <div class="sgif-custom-preview"><span>No GIF selected</span></div>
            </div>
            <div class="sgif-selected">
                <span class="sgif-selected-text">No GIF selected</span>
                <button class="sgif-add" type="button" disabled>Add GIF</button>
            </div>
        `;

        document.body.appendChild(panel);

        const search = panel.querySelector(".sgif-search");
        const searchButton = panel.querySelector(".sgif-search-button");
        const close = panel.querySelector(".sgif-x");
        const add = panel.querySelector(".sgif-add");
        const customFile = panel.querySelector(".sgif-custom-file");

        close.addEventListener("click", event => {
            event.preventDefault();
            closePanel();
        });

        searchButton.addEventListener("click", event => {
            event.preventDefault();
            renderResults(search.value, true);
        });

        search.addEventListener("keydown", event => {
            if (event.key === "Enter") {
                event.preventDefault();
                renderResults(search.value, true);
            }
            if (event.key === "Escape") {
                event.preventDefault();
                closePanel();
            }
        });

        customFile.addEventListener("change", event => {
            const file = event.target.files?.[0];
            if (!file) return;

            const fileName = file.name.toLowerCase();
            const isGif = file.type === "image/gif" || fileName.endsWith(".gif");
            const isPng = file.type === "image/png" || fileName.endsWith(".png");

            if (!isGif && !isPng) {
                alert("Only GIF and PNG files are supported.");
                customFile.value = "";
                return;
            }

            if (file.size > MAX_CUSTOM_SIZE) {
                alert("Custom GIF is too large. Max size is 10 MB.");
                customFile.value = "";
                return;
            }

            if (selectedCustomUrl) URL.revokeObjectURL(selectedCustomUrl);

            selectedGif = null;
            selectedCustomFile = file;
            selectedCustomUrl = URL.createObjectURL(file);

            panel.querySelectorAll(".sgif-item.selected").forEach(item => {
                item.classList.remove("selected");
            });

            const preview = panel.querySelector(".sgif-custom-preview");
            preview.innerHTML = "";
            const img = document.createElement("img");
            img.src = selectedCustomUrl;
            img.alt = "Selected GIF";
            preview.appendChild(img);

            const selectedText = panel.querySelector(".sgif-selected-text");
            selectedText.textContent = "Custom GIF";
            add.disabled = false;
        });

        add.addEventListener("click", async event => {
            event.preventDefault();

            if (selectedCustomFile) {
                add.disabled = true;
                add.textContent = "Uploading...";
                try {
                    await insertCustomGif(currentInput, selectedCustomFile);
                } finally {
                    add.textContent = "Add GIF";
                }
                closePanel();
                return;
            }

            if (selectedGif) {
                insertGif(currentInput, selectedGif);
                closePanel();
            }
        });

        renderResults("", false);
        positionPanel();
        search.focus();
    }


    function renderResults(query, searched) {
        if (!panel) return;

        const results = panel.querySelector(".sgif-results");
        const status = panel.querySelector(".sgif-status");
        const add = panel.querySelector(".sgif-add");
        const selectedText = panel.querySelector(".sgif-selected-text");

        selectedGif = null;

        if (selectedCustomUrl) {
            URL.revokeObjectURL(selectedCustomUrl);
            selectedCustomUrl = null;
        }

        selectedCustomFile = null;
        add.disabled = true;
        selectedText.textContent = "No GIF selected";
        results.innerHTML = "";

        const customPreview = panel.querySelector(".sgif-custom-preview");
        if (customPreview) customPreview.innerHTML = "<span>No GIF selected</span>";

        const gifs = searchGifs(query);

        status.textContent = searched
            ? (gifs.length ? `${gifs.length} GIFs found` : "No GIFs found")
            : "Popular GIFs";

        if (!gifs.length) {
            const empty = document.createElement("div");
            empty.className = "sgif-loading";
            empty.textContent = "No GIFs found.";
            results.appendChild(empty);
            return;
        }

        for (const gif of gifs) {
            const item = document.createElement("button");
            item.className = "sgif-item";
            item.type = "button";
            item.title = gif.name || gif.folder;

            const img = document.createElement("img");
            img.src = getGifUrl(gif);
            img.alt = gif.name || gif.folder;
            img.loading = "lazy";

            img.addEventListener("error", () => {
                item.style.display = "none";
            });

            item.appendChild(img);

            item.addEventListener("click", event => {
                event.preventDefault();

                if (selectedCustomUrl) {
                    URL.revokeObjectURL(selectedCustomUrl);
                    selectedCustomUrl = null;
                }

                selectedCustomFile = null;

                const customInput = panel.querySelector(".sgif-custom-file");
                if (customInput) customInput.value = "";

                const customPreview = panel.querySelector(".sgif-custom-preview");
                if (customPreview) customPreview.innerHTML = "<span>No GIF selected</span>";

                results.querySelectorAll(".sgif-item.selected").forEach(selected => {
                    selected.classList.remove("selected");
                });

                item.classList.add("selected");
                selectedGif = gif;
                selectedText.textContent = gif.name || gif.folder;
                add.disabled = false;
            });

            results.appendChild(item);
        }
    }


    // =========================================================
    // INPUT VALUE
    // =========================================================

    function getInputValue(input) {
        return input.value || "";
    }


    function setInputValue(input, value) {
        const setter = Object.getOwnPropertyDescriptor(
            HTMLTextAreaElement.prototype,
            "value"
        )?.set;

        if (setter) {
            setter.call(input, value);
        } else {
            input.value = value;
        }

        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
    }


    // =========================================================
    // NORMAL GIF EKLE
    // =========================================================

    function insertGif(input, gif) {
        if (!input) return;

        const value = getInputValue(input);

        if (decodeGif(value) || extractCustom(value)) {
            alert("You can only add one GIF per comment.");
            return;
        }

        const text = value.trim();
        const separator = text ? " " : "";
        const marker = encodeGif(gif.folder);
        const fallbackText = makeFallbackText(gif.name);

        setInputValue(input, text + separator + fallbackText + marker);
    }


    // =========================================================
    // CUSTOM GIF EKLE
    // =========================================================

    async function insertCustomGif(input, file) {
        if (!input || !file) return;

        const value = getInputValue(input);

        if (decodeGif(value) || extractCustom(value)) {
            alert("You can only add one GIF per comment.");
            return;
        }

        let remoteUrl;

        try {
            remoteUrl = await uploadViaBackground(file);
        } catch (e) {
            console.error("[ScratchGifs] upload hatası", e);
            alert("Could not upload GIF. Please try again.\n\n" + (e.message || e));
            return;
        }

        const id = createCustomId();
        const marker = encodeCustom(id, remoteUrl);

        downloadedCustoms.set(id, {
            url: remoteUrl,
            name: file.name || "Custom GIF"
        });

        const text = value.trim();
        const separator = text ? " " : "";
        const customName = file.name
            ? file.name.replace(/\.[^.]+$/, "")
            : "Custom GIF";
        const fallbackText = makeFallbackText(customName);

        const fullText = text + separator + fallbackText + " " + marker;

        setInputValue(input, fullText);
    }


    // =========================================================
    // YORUM INPUTU MU?
    // =========================================================

    function isMessageInput(element) {
        if (!(element instanceof HTMLTextAreaElement)) return false;

        const name = (element.getAttribute("name") || "").toLowerCase();
        const className = (
            typeof element.className === "string" ? element.className : ""
        ).toLowerCase();

        if (name === "content") return true;
        if (name === "compose-comment") return true;
        if (className.includes("scratchtoolscheck")) return true;

        const placeholder = (
            element.getAttribute("placeholder") || ""
        ).toLowerCase();

        const words = [
            "comment", "comments", "yorum", "yorum yaz",
            "write a comment", "leave a comment", "add a comment"
        ];

        if (words.some(word => placeholder.includes(word))) return true;

        const aria = (element.getAttribute("aria-label") || "").toLowerCase();
        if (words.some(word => aria.includes(word))) return true;

        return false;
    }


    // =========================================================
    // TÜM YORUM INPUTLARINI BUL
    // =========================================================

    function findMessageInputs() {
        const inputs = document.querySelectorAll(
            [
                'textarea[name="content"]',
                'textarea[name="compose-comment"]',
                "textarea.scratchtoolsCheck"
            ].join(",")
        );

        for (const input of inputs) {
            if (isMessageInput(input)) addGifButton(input);
        }

        const allTextareas = document.querySelectorAll("textarea");
        for (const textarea of allTextareas) {
            if (isMessageInput(textarea)) addGifButton(textarea);
        }
    }


    // =========================================================
    // GIF BUTONU
    // =========================================================

    function addGifButton(input) {
        if (!input) return;

        if (input.dataset.scratchGifReady === "1") {
            const next = input.nextElementSibling;
            if (next && next.classList.contains("scratch-gif-button")) return;
            delete input.dataset.scratchGifReady;
        }

        const parent = input.parentElement;
        if (!parent) return;

        const existing = parent.querySelector(".scratch-gif-button");
        if (existing) {
            input.dataset.scratchGifReady = "1";
            return;
        }

        const button = document.createElement("button");
        button.className = "scratch-gif-button";
        button.type = "button";
        button.textContent = "GIF";
        button.title = "Add a GIF";
        button.setAttribute("aria-label", "Add a GIF");

        button.addEventListener("mousedown", event => {
            event.preventDefault();
            event.stopPropagation();
        });

        button.addEventListener("click", event => {
            event.preventDefault();
            event.stopPropagation();

            if (panel && currentButton === button) {
                closePanel();
                return;
            }

            createPanel(input, button);
        });

        input.insertAdjacentElement("afterend", button);
        input.dataset.scratchGifReady = "1";
    }


    // =========================================================
    // TEXT NODE
    // =========================================================

    function getTextNodes(root) {
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        const nodes = [];
        let node;
        while ((node = walker.nextNode())) {
            nodes.push(node);
        }
        return nodes;
    }


    // =========================================================
    // FALLBACK TEMİZLE
    // =========================================================

    function stripFallback(text) {
        const fallbackPattern =
            /GIF:\s*.*?\.\s*You can't see GIF if you don't have GIF extension\.?/i;
        return text.replace(fallbackPattern, "").trim();
    }


    // =========================================================
    // NORMAL GIF YORUMLARINI GÖSTER
    // =========================================================

    function renderGifComments() {
        const nodes = getTextNodes(document.body);

        for (const node of nodes) {
            const text = node.nodeValue || "";

            if (text.includes(START)) {
                const folder = decodeGif(text);
                if (folder) {
                    const gif = catalog.find(item => item.folder === folder);
                    if (gif) {
                        const parent = node.parentElement;
                        if (parent && !parent.querySelector(".sgif-comment")) {
                            const clean = removeMarker(text);
                            const visible = stripFallback(clean);
                            node.nodeValue = visible;

                            const img = document.createElement("img");
                            img.className = "sgif-comment";
                            img.src = getGifUrl(gif);
                            img.alt = gif.name || gif.folder;
                            img.title = gif.name || gif.folder;
                            img.loading = "lazy";
                            img.addEventListener("error", () => img.remove());
                            parent.appendChild(img);
                        }
                    }
                }
            }
        }

        renderCustomGifComments();
    }


    // =========================================================
    // CUSTOM GIF YORUMLARI (Sadece GIF, indirme butonu YOK)
    // =========================================================

    function renderCustomGifComments() {
        const nodes = getTextNodes(document.body);

        for (const node of nodes) {
            const text = node.nodeValue || "";

            const custom = extractCustom(text);
            if (!custom) continue;

            const parent = node.parentElement;
            if (!parent) continue;

            // Zaten eklenmiş mi?
            if (parent.querySelector(".sgif-custom-comment") ||
                parent.querySelector(".sgif-custom-wrapper")) {
                continue;
            }

            // Metni temizle
            let cleaned = text.replace(CUSTOM_REGEX, "");
            cleaned = stripFallback(cleaned);
            node.nodeValue = cleaned;

            // Direkt göster (sadece img, buton yok)
            const img = document.createElement("img");
            img.className = "sgif-custom-comment";
            img.src = custom.url;
            img.alt = "Custom GIF";
            img.title = "Custom GIF";
            img.loading = "lazy";
            img.addEventListener("error", () => img.remove());

            parent.appendChild(img);
        }
    }


    // =========================================================
    // SAYFAYI TARA
    // =========================================================

    function scanPage() {
        if (scanTimer) return;
        scanTimer = setTimeout(() => {
            scanTimer = null;
            findMessageInputs();
            renderGifComments();
        }, 100);
    }


    const observer = new MutationObserver(() => {
        scanPage();
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });


    let lastUrl = location.href;
    setInterval(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            setTimeout(() => {
                findMessageInputs();
                renderGifComments();
            }, 250);
        }
    }, 300);


    window.addEventListener("resize", () => {
        if (panel) positionPanel();
        scanPage();
    });

    window.addEventListener("scroll", () => {
        if (panel) positionPanel();
    }, true);

    document.addEventListener("keydown", event => {
        if (event.key === "Escape" && panel) closePanel();
    });

    document.addEventListener("mousedown", event => {
        if (!panel) return;
        if (panel.contains(event.target)) return;
        if (currentButton && currentButton.contains(event.target)) return;
        closePanel();
    });


    (async () => {
        await loadCatalog();
        findMessageInputs();
        renderGifComments();
        console.log("[ScratchGifs] GIF support aktif.");
    })();

})();